#pragma once

template<typename T> class Vec2D
{
public:
	Vec2D(T x, T y) : x_(x), y_(y) {}
	T x() const {return x_;}
	T y() const {return y_;}
	T operator*(const Vec2D<T>& r) {
		return x_*r.x_ + y_*r.y_;
	}

protected:
	T x_, y_;
};

template<typename T> class Vec3D : public Vec2D<T>
{
public:
	Vec3D(T x, T y, T z) : Vec2D<T>(x, y) { z_ = z;}
	T z() const {return z_;}
	T operator*(const Vec3D<T>& r) {//inner product of 2 vector
		return Vec2D<T>::operator*(r) + z_*r.z_;
	}
	operator Matrix<T>() {
		Matrix<T> m{1,3};
		m[1][1] = this->x();
		m[1][2] = this->y();
		m[1][3] = z();
		return m;
	}
	Vec3D<T> operator^(const Vec3D<T>& r) {//counter product X
		return Vec3D<T> {
			this->y() * r.z() - z() * r.y(),
			this->x() * r.z() - z() * r.x(), 
			this->x() * r.y() - this->y() * r.x()
		};
	}

protected:
	T z_;
};

template<typename T> class Vec4D : public Vec3D<T>
{
public:
	Vec4D(T x, T y, T z, T a) : Vec3D<T>(x, y, z) { a_ = a;}
	T a() {return a_;}
	T operator*(const Vec4D<T>& r) {//dot product
		return Vec3D<T>::operator*(r) + a_ * r.a_;
	}
	operator Matrix<T>() {
		Matrix<T> m{1,4};
		m[1][1] = this->x();
		m[1][2] = this->y();
		m[1][3] = this->z();
		m[1][4] = a();
		return m;
	}

protected:
	T a_;
};

template<typename T> std::ostream& operator<<(std::ostream& o, const Vec3D<T>& r) {
	o << '(' << r.x() << ',' << r.y() << ',' << r.z() << ')';
	return o;
}
